#
b<-colnames(data4)
data5<-data4[,grep("z",b),with=FALSE]



